import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  Grid2X2, 
  ArrowRightLeft, 
  Settings, 
  Activity, 
  Eye, 
  EyeOff, 
  Bell, 
  ScanLine, 
  ChevronDown, 
  ArrowDown, 
  ArrowUp, 
  CreditCard, 
  Flame, 
  Search, 
  Sparkles, 
  Shield, 
  ShieldCheck,
  Usb, 
  Lock, 
  ChevronRight, 
  Globe,
  History,
  SquareTerminal,
  Radar
} from 'lucide-react';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { useAccount } from 'wagmi';
import { INITIAL_TOKENS, INITIAL_NFTS, COLORS, MARKET_TOKENS, MOCK_HISTORY } from './constants';
import { Token, NFT, Tab, ToastMessage, TransactionDetails } from './types';
import { Onboarding } from './components/Onboarding';
import { ToastSystem } from './components/ToastSystem';
import { Terminal } from './components/Terminal';
import { Track } from './components/Track';
import { TransactionSigner } from './components/TransactionSigner';
import { RecoveryPhrase } from './components/RecoveryPhrase';
import { Watchlist } from './components/Watchlist';
import { ReceiveModal } from './components/ReceiveModal';
import { BuyModal } from './components/BuyModal';
import { StakingModal } from './components/StakingModal';
import { Explore } from './components/Explore';
import { TokenDetail } from './components/TokenDetail';
import { NFTDetail } from './components/NFTDetail';
import { fetchTopTokens, fetchTokenBalances } from './services/moralis';

export default function App() {
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>(Tab.HOME);
  const [privacyMode, setPrivacyMode] = useState(false);
  const [tokens, setTokens] = useState<Token[]>(INITIAL_TOKENS);
  const [marketTokens, setMarketTokens] = useState<Token[]>(MARKET_TOKENS);
  const [nfts, setNfts] = useState<NFT[]>(INITIAL_NFTS);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  // Wallet Connection
  const { address, isConnected } = useAccount();

  // New States for Features
  const [homeView, setHomeView] = useState<'ASSETS' | 'NFT' | 'WATCHLIST'>('ASSETS');
  const [watchlistIds, setWatchlistIds] = useState<string[]>(['solana', 'wif', 'bonk']);
  const [transactionToSign, setTransactionToSign] = useState<TransactionDetails | null>(null);
  const [showRecoveryPhrase, setShowRecoveryPhrase] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showStakingModal, setShowStakingModal] = useState(false);
  const [selectedToken, setSelectedToken] = useState<Token | null>(null);
  const [selectedNft, setSelectedNft] = useState<NFT | null>(null);
  const [hwWalletConnected, setHwWalletConnected] = useState(false);

  // Notification Settings States
  const [priceAlertsEnabled, setPriceAlertsEnabled] = useState(true);
  const [transactionAlertsEnabled, setTransactionAlertsEnabled] = useState(true);

  // Fetch Moralis Data
  useEffect(() => {
    const loadMarketData = async () => {
      try {
        const topTokens = await fetchTopTokens();
        if (topTokens.length > 0) {
          setMarketTokens(prev => [...prev, ...topTokens]);
          setTokens(prev => prev.map(t => {
            const fresh = topTokens.find(ft => ft.symbol === t.symbol);
            return fresh ? { ...t, price: fresh.price, change24h: fresh.change24h } : t;
          }));
        }
      } catch (error) {
        console.error("Error loading market data", error);
      }
    };
    loadMarketData();
  }, []);

  // Fetch User Balances if connected
  useEffect(() => {
    const loadUserBalances = async () => {
       if (isConnected && address) {
          const balances = await fetchTokenBalances(address);
          if (balances.length > 0) {
             setTokens(balances);
          }
       }
    };
    loadUserBalances();
  }, [isConnected, address]);


  // Computed total balance
  const totalBalance = tokens.reduce((acc, t) => acc + (t.balance * t.price), 0);
  const balanceDisplay = privacyMode 
    ? '••••••' 
    : `$${totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const addToast = (title: string, type: ToastMessage['type'], subtitle?: string, image?: string) => {
    const id = Math.random().toString(36).substring(7);
    setToasts(prev => [...prev, { id, title, type, subtitle, image }]);
    setTimeout(() => removeToast(id), 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleBurn = (nftId: string) => {
    const nft = nfts.find(n => n.id === nftId);
    if (!nft) return;
    setNfts(prev => prev.filter(n => n.id !== nftId));
    if (selectedNft?.id === nftId) setSelectedNft(null);
    const burnValue = 0.002;
    setTokens(prev => prev.map(t => t.symbol === 'SOL' ? { ...t, balance: t.balance + burnValue } : t));
    addToast('Burn Successful', 'burn', `+${burnValue} SOL Redeemed`, nft.image);
  };

  const toggleWatchlist = (id: string) => {
    setWatchlistIds(prev => 
      prev.includes(id) ? prev.filter(wId => wId !== id) : [...prev, id]
    );
  };

  const initSendTransaction = () => {
    setTransactionToSign({
      type: 'SEND',
      fromToken: tokens[0], // SOL
      fromAmount: 1.5,
      recipient: '8x7...2v3d', // Mock recipient
      fee: 0.00005,
      network: 'SOL'
    });
  };

  const handleDAppTransaction = (details: Partial<TransactionDetails>) => {
    setTransactionToSign({
        type: 'DAPP',
        fromToken: tokens[0], // SOL usually default
        toToken: INITIAL_TOKENS[4], // Default USDC if needed, or overridden
        fromAmount: details.fromAmount || 0,
        fee: 0.00005,
        network: 'SOL',
        dAppName: details.dAppName,
        dAppIcon: details.dAppIcon,
        ...details
    } as TransactionDetails);
  };

  if (!hasOnboarded) {
    return <Onboarding onComplete={() => setHasOnboarded(true)} />;
  }

  return (
    <div class="min-h-screen bg-[#0C0C0C] text-white font-sans flex flex-col overflow-hidden max-w-md mx-auto relative shadow-2xl">
      <ToastSystem toasts={toasts} removeToast={removeToast} />

      {/* Overlays */}
      {transactionToSign && (
        <TransactionSigner 
          transaction={transactionToSign}
          onConfirm={() => {
            setTransactionToSign(null);
            addToast('Transaction Sent', 'success', 'Confirmed on chain');
          }}
          onCancel={() => setTransactionToSign(null)}
        />
      )}

      {showRecoveryPhrase && (
        <RecoveryPhrase onClose={() => setShowRecoveryPhrase(false)} />
      )}

      {showReceiveModal && (
        <ReceiveModal onClose={() => setShowReceiveModal(false)} />
      )}
      
      {showBuyModal && (
        <BuyModal onClose={() => setShowBuyModal(false)} />
      )}

      {showStakingModal && (
        <StakingModal 
          tokenSymbol={selectedToken?.symbol || 'SOL'} 
          onClose={() => setShowStakingModal(false)} 
        />
      )}

      {selectedToken && (
        <TokenDetail 
          token={selectedToken}
          onBack={() => setSelectedToken(null)}
          onBuy={() => { setShowBuyModal(true); setSelectedToken(null); }}
          onSwap={() => { setActiveTab(Tab.TERMINAL); setSelectedToken(null); }}
          onStake={() => setShowStakingModal(true)}
        />
      )}

      {selectedNft && (
        <NFTDetail
          nft={selectedNft}
          onBack={() => setSelectedNft(null)}
          onBurn={handleBurn}
        />
      )}

      {/* Header (Global) */}
      <header class="px-5 pt-4 pb-2 flex justify-between items-center z-10 bg-[#0C0C0C]">
        <div class="flex items-center gap-3">
          <ConnectButton 
            accountStatus={{
              smallScreen: 'avatar',
              largeScreen: 'full',
            }}
            showBalance={false}
            chainStatus="icon"
          />
        </div>
        <div class="flex items-center gap-4">
          <button class="text-gray-400 hover:text-white transition-colors active:scale-90">
             <ScanLine size={24} />
          </button>
          <div class="relative cursor-pointer group active:scale-90 transition-transform">
            <Bell size={24} class="text-gray-400 group-hover:text-white transition-colors" />
            <span class="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#0C0C0C]"></span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main class="flex-1 overflow-y-auto pb-24 scrollbar-hide">
        
        {/* HOME TAB */}
        {activeTab === Tab.HOME && (
          <div class="flex flex-col gap-6 p-5 animate-fade-in">
            {/* Balance Card */}
            <div class="flex flex-col items-center mt-4">
              <div 
                class="flex items-center gap-2 cursor-pointer group"
                onClick={() => setPrivacyMode(!privacyMode)}
              >
                <h1 class="text-5xl font-extrabold tracking-tight select-none tabular-nums">
                  {balanceDisplay}
                </h1>
                <span class="opacity-0 group-hover:opacity-100 transition-opacity text-gray-500">
                  {privacyMode ? <Eye size={20}/> : <EyeOff size={20}/>}
                </span>
              </div>
              <div class={`mt-2 flex items-center gap-1 text-sm font-medium ${tokens[0].change24h >= 0 ? 'text-[#22c55e]' : 'text-red-500'}`}>
                {tokens[0].change24h >= 0 ? '+' : ''}${(tokens[0].balance * tokens[0].price * (tokens[0].change24h/100)).toFixed(2)} ({tokens[0].change24h}%)
                <span class="text-gray-500 ml-1">Today</span>
              </div>
            </div>

            {/* Action Grid */}
            <div class="grid grid-cols-4 gap-4 mt-2">
              {[
                { label: 'Receive', icon: ArrowDown, color: 'bg-[#1C1C1E]', onClick: () => setShowReceiveModal(true) },
                { label: 'Send', icon: ArrowUp, color: 'bg-[#1C1C1E]', onClick: initSendTransaction },
                { label: 'Trade', icon: ArrowRightLeft, color: 'bg-[#1C1C1E]', onClick: () => setActiveTab(Tab.TERMINAL) },
                { label: 'Buy', icon: CreditCard, color: 'bg-[#AB9FF2]', text: 'text-black', onClick: () => setShowBuyModal(true) }
              ].map((action) => (
                <button 
                  key={action.label} 
                  onClick={action.onClick}
                  class="flex flex-col items-center gap-2 group"
                >
                  <div class={`w-14 h-14 ${action.color} rounded-2xl flex items-center justify-center transition-all duration-200 group-active:scale-90 shadow-lg`}>
                    <action.icon size={24} class={action.text || 'text-[#AB9FF2]'} />
                  </div>
                  <span class="text-xs font-medium text-gray-300">{action.label}</span>
                </button>
              ))}
            </div>

            {/* Assets / NFT / Watchlist Toggle */}
            <div class="mt-4">
               <div class="flex gap-6 border-b border-white/5 pb-2 mb-4">
                  <button 
                    onClick={() => setHomeView('ASSETS')}
                    class={`text-sm font-bold transition-colors pb-2 relative ${homeView === 'ASSETS' ? 'text-white' : 'text-gray-500'}`}
                  >
                    Crypto
                    {homeView === 'ASSETS' && <div class="absolute -bottom-[9px] left-0 right-0 h-0.5 bg-[#AB9FF2] rounded-full" />}
                  </button>
                  <button 
                    onClick={() => setHomeView('NFT')}
                    class={`text-sm font-bold transition-colors pb-2 relative ${homeView === 'NFT' ? 'text-white' : 'text-gray-500'}`}
                  >
                    Collectibles
                    {homeView === 'NFT' && <div class="absolute -bottom-[9px] left-0 right-0 h-0.5 bg-[#AB9FF2] rounded-full" />}
                  </button>
                  <button 
                    onClick={() => setHomeView('WATCHLIST')}
                    class={`text-sm font-bold transition-colors pb-2 relative ${homeView === 'WATCHLIST' ? 'text-white' : 'text-gray-500'}`}
                  >
                    Watchlist
                    {homeView === 'WATCHLIST' && <div class="absolute -bottom-[9px] left-0 right-0 h-0.5 bg-[#AB9FF2] rounded-full" />}
                  </button>
               </div>

              {homeView === 'ASSETS' && (
                <div class="flex flex-col gap-3">
                  {tokens.map((token) => (
                    <div 
                      key={token.id} 
                      onClick={() => setSelectedToken(token)}
                      class="flex items-center justify-between p-3 rounded-2xl hover:bg-[#1C1C1E] transition-colors cursor-pointer group active:scale-[0.98]"
                    >
                      <div class="flex items-center gap-3">
                        <div class="relative">
                           <img src={token.image} alt={token.name} class="w-10 h-10 rounded-full object-cover" />
                           <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-black rounded-full flex items-center justify-center border border-[#1C1C1E]">
                             <div class={`w-2 h-2 rounded-full ${token.network === 'SOL' ? 'bg-purple-400' : 'bg-blue-400'}`}></div>
                           </div>
                        </div>
                        <div class="flex flex-col">
                          <span class="font-bold text-base">{token.name}</span>
                          <div class="flex items-center gap-1">
                            <span class="text-xs text-gray-400">{token.balance.toFixed(4)} {token.symbol}</span>
                          </div>
                        </div>
                      </div>
                      <div class="flex flex-col items-end">
                        <span class="font-bold tabular-nums">
                          {privacyMode ? '****' : `$${(token.balance * token.price).toLocaleString(undefined, { maximumFractionDigits: 2 })}`}
                        </span>
                        <span class={`text-xs font-medium ${token.change24h >= 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                           {token.change24h > 0 ? '+' : ''}{token.change24h.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {homeView === 'NFT' && (
                 <div class="grid grid-cols-2 gap-4 animate-fade-in">
                    {/* Spam Toggle */}
                    <div class="col-span-2 flex items-center justify-between bg-[#1C1C1E]/50 p-3 rounded-xl cursor-pointer hover:bg-[#1C1C1E] transition-colors">
                        <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center">
                            <EyeOff size={16} class="text-gray-400" />
                        </div>
                        <span class="font-semibold text-sm">Hidden / Spam</span>
                        </div>
                        <ChevronDown size={16} class="text-gray-500 -rotate-90" />
                    </div>
                    {nfts.map((nft) => (
                    <div 
                    key={nft.id} 
                    onClick={() => setSelectedNft(nft)}
                    class="group relative bg-[#1C1C1E] rounded-2xl overflow-hidden shadow-lg transition-transform hover:-translate-y-1 cursor-pointer"
                    >
                        <img src={nft.image} alt={nft.name} class="w-full h-40 object-cover" />
                        <div class="p-3">
                            <h4 class="font-bold text-sm truncate">{nft.name}</h4>
                            <p class="text-xs text-gray-400 truncate">{nft.collection}</p>
                            <div class="flex justify-between items-center mt-3">
                                <span class="text-xs font-mono bg-black/50 px-1.5 py-0.5 rounded text-gray-300">
                                    {nft.estValueSol} SOL
                                </span>
                            </div>
                        </div>
                    </div>
                    ))}
                 </div>
              )}

              {homeView === 'WATCHLIST' && (
                <Watchlist watchlistIds={watchlistIds} toggleWatchlist={toggleWatchlist} />
              )}
            </div>
          </div>
        )}

        {/* TERMINAL TAB (Replaces Swap) */}
        {activeTab === Tab.TERMINAL && (
           <Terminal />
        )}

        {/* TRACK TAB (New) */}
        {activeTab === Tab.TRACK && (
           <Track />
        )}

        {/* EXPLORE TAB */}
        {activeTab === Tab.EXPLORE && (
          <Explore onRequestTransaction={handleDAppTransaction} />
        )}

        {/* SETTINGS TAB */}
        {activeTab === Tab.SETTINGS && (
          <div class="p-5 animate-fade-in">
             <h2 class="text-2xl font-bold mb-6">Settings</h2>
             
             {/* Profile */}
             <div class="bg-[#1C1C1E] rounded-2xl p-4 flex items-center gap-4 mb-6">
                 <div class="w-16 h-16 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 p-0.5">
                   <div class="w-full h-full rounded-full bg-black flex items-center justify-center overflow-hidden">
                       <img src="https://picsum.photos/id/64/200/200" alt="Avatar" class="w-full h-full object-cover" />
                   </div>
                </div>
                <div>
                   <h3 class="font-bold text-lg">@cryptowhale</h3>
                   <p class="text-sm text-gray-400">Main Wallet</p>
                </div>
             </div>

             {/* Security Section */}
             <h3 class="text-gray-500 font-bold text-xs uppercase tracking-wider mb-3 pl-1">Security & Privacy</h3>
             <div class="bg-[#1C1C1E] rounded-2xl overflow-hidden mb-6">
                <button 
                  onClick={() => setShowRecoveryPhrase(true)}
                  class="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
                >
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-[#AB9FF2]/10 flex items-center justify-center text-[#AB9FF2]">
                         <Lock size={18} />
                      </div>
                      <span class="font-medium">Show Secret Phrase</span>
                   </div>
                   <ChevronRight size={18} class="text-gray-500" />
                </button>
                <div class="h-[1px] bg-white/5 mx-4" />
                <button 
                  onClick={() => setHwWalletConnected(!hwWalletConnected)}
                  class="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
                >
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
                         <Usb size={18} />
                      </div>
                      <span class="font-medium">Hardware Wallet</span>
                   </div>
                   <span class={`text-xs px-2 py-1 rounded-full font-bold ${hwWalletConnected ? 'bg-green-500/20 text-green-500' : 'bg-gray-800 text-gray-500'}`}>
                      {hwWalletConnected ? 'Connected' : 'Disconnected'}
                   </span>
                </button>
             </div>

             {/* Notifications Section */}
             <h3 class="text-gray-500 font-bold text-xs uppercase tracking-wider mb-3 pl-1">Notifications</h3>
             <div class="bg-[#1C1C1E] rounded-2xl overflow-hidden mb-6">
                <div class="flex items-center justify-between p-4 border-b border-white/5">
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400">
                         <Bell size={18} />
                      </div>
                      <span class="font-medium">Price Alerts</span>
                   </div>
                   <button 
                      onClick={() => setPriceAlertsEnabled(!priceAlertsEnabled)}
                      class={`w-12 h-6 rounded-full transition-colors relative ${priceAlertsEnabled ? 'bg-[#AB9FF2]' : 'bg-gray-700'}`}
                   >
                      <div class={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${priceAlertsEnabled ? 'left-7' : 'left-1'}`} />
                   </button>
                </div>
                <div class="flex items-center justify-between p-4">
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400">
                         <ShieldCheck size={18} />
                      </div>
                      <span class="font-medium">Transaction Confirmations</span>
                   </div>
                   <button 
                      onClick={() => setTransactionAlertsEnabled(!transactionAlertsEnabled)}
                      class={`w-12 h-6 rounded-full transition-colors relative ${transactionAlertsEnabled ? 'bg-[#AB9FF2]' : 'bg-gray-700'}`}
                   >
                      <div class={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${transactionAlertsEnabled ? 'left-7' : 'left-1'}`} />
                   </button>
                </div>
             </div>
             
             {/* Activity Section */}
             <h3 class="text-gray-500 font-bold text-xs uppercase tracking-wider mb-3 pl-1">Recent Activity</h3>
             <div class="bg-[#1C1C1E] rounded-2xl overflow-hidden mb-6">
                {MOCK_HISTORY.map((tx, i) => (
                   <div key={tx.id} class={`flex items-center justify-between p-4 ${i !== MOCK_HISTORY.length - 1 ? 'border-b border-white/5' : ''} hover:bg-white/5 transition-colors cursor-pointer`}>
                      <div class="flex items-center gap-3">
                         <div class={`w-10 h-10 rounded-full flex items-center justify-center ${
                            tx.type === 'RECEIVE' ? 'bg-green-500/10 text-green-500' :
                            tx.type === 'SEND' ? 'bg-gray-800 text-gray-400' :
                            tx.type === 'BURN' ? 'bg-orange-500/10 text-orange-500' :
                            tx.type === 'STAKE' ? 'bg-[#AB9FF2]/10 text-[#AB9FF2]' :
                            'bg-gray-800 text-gray-400'
                         }`}>
                            {tx.image ? (
                               <img src={tx.image} class="w-full h-full rounded-full object-cover" />
                            ) : (
                                tx.type === 'RECEIVE' ? <ArrowDown size={18} /> :
                                tx.type === 'SEND' ? <ArrowUp size={18} /> :
                                tx.type === 'SWAP' ? <ArrowRightLeft size={18} /> :
                                tx.type === 'BURN' ? <Flame size={18} /> :
                                tx.type === 'STAKE' ? <ShieldCheck size={18} /> :
                                <History size={18} />
                            )}
                         </div>
                         <div>
                            <div class="font-bold text-sm text-white">{tx.title}</div>
                            <div class="text-xs text-gray-400">{tx.subtitle}</div>
                         </div>
                      </div>
                      <div class="text-right">
                         <div class={`font-bold text-sm ${
                           tx.direction === 'IN' ? 'text-green-500' : 'text-white'
                         }`}>
                           {tx.amount}
                         </div>
                         <div class="text-xs text-gray-500">{tx.date}</div>
                      </div>
                   </div>
                ))}
                <div class="p-3 text-center border-t border-white/5">
                   <button class="text-xs font-bold text-gray-500 hover:text-white transition-colors">View All History</button>
                </div>
             </div>

             {/* General Section */}
             <h3 class="text-gray-500 font-bold text-xs uppercase tracking-wider mb-3 pl-1">General</h3>
             <div class="bg-[#1C1C1E] rounded-2xl overflow-hidden">
                <div class="flex items-center justify-between p-4 border-b border-white/5">
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400">
                         <Activity size={18} />
                      </div>
                      <span class="font-medium">Network</span>
                   </div>
                   <span class="text-sm text-gray-400">Solana Mainnet</span>
                </div>
                <div class="flex items-center justify-between p-4">
                   <div class="flex items-center gap-3">
                      <div class="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400">
                         <Eye size={18} />
                      </div>
                      <span class="font-medium">App Appearance</span>
                   </div>
                   <span class="text-sm text-gray-400">OLED Dark</span>
                </div>
             </div>
          </div>
        )}

      </main>

      {/* Bottom Navigation */}
      <nav class="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-[#0C0C0C]/90 backdrop-blur-xl border-t border-white/5 pb-6 pt-2 px-4 flex justify-between items-center z-40">
         <NavButton 
            active={activeTab === Tab.HOME} 
            onClick={() => setActiveTab(Tab.HOME)} 
            icon={Wallet}
            label="Home"
         />
         <NavButton 
            active={activeTab === Tab.TERMINAL} 
            onClick={() => setActiveTab(Tab.TERMINAL)} 
            icon={SquareTerminal}
            label="Terminal"
         />
         <div class="relative -top-4">
            <button 
              onClick={() => setActiveTab(Tab.TRACK)}
              class={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 active:scale-90 ${activeTab === Tab.TRACK ? 'bg-[#AB9FF2] text-black scale-110 ring-4 ring-[#AB9FF2]/20' : 'bg-[#1C1C1E] text-white border border-white/10'}`}
            >
              <Radar size={24} />
            </button>
         </div>
         <NavButton 
            active={activeTab === Tab.EXPLORE} 
            onClick={() => setActiveTab(Tab.EXPLORE)} 
            icon={Search}
            label="Explore" 
         />
         <NavButton 
            active={activeTab === Tab.SETTINGS} 
            onClick={() => setActiveTab(Tab.SETTINGS)} 
            icon={Settings} 
            label="Settings"
         />
      </nav>
    </div>
  );
}

const NavButton = ({ active, onClick, icon: Icon, label }: { active: boolean, onClick: () => void, icon: React.ComponentType<any>, label: string }) => (
  <button 
    onClick={onClick}
    class={`p-1 rounded-xl transition-all duration-300 active:scale-90 flex flex-col items-center gap-1 w-14 ${active ? 'text-[#AB9FF2]' : 'text-gray-500 hover:text-gray-300'}`}
  >
    <Icon size={24} strokeWidth={active ? 2.5 : 2} />
    <span class="text-[10px] font-medium">{label}</span>
  </button>
);