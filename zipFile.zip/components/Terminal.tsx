import React, { useState } from 'react';
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CHART_DATA, INITIAL_TOKENS } from '../constants';
import { ArrowUpRight, ArrowDownRight, Settings, ChevronDown, Zap, History, BookOpen } from 'lucide-react';
import { Token } from '../types';

export const Terminal: React.FC = () => {
  const [mode, setMode] = useState<'SPOT' | 'PERPS'>('SPOT');
  const [side, setSide] = useState<'BUY' | 'SELL' | 'LONG' | 'SHORT'>('BUY');
  const [leverage, setLeverage] = useState(1);
  const [amount, setAmount] = useState('');

  // Determine active side based on mode
  const currentSide = mode === 'SPOT' 
    ? (side === 'LONG' || side === 'SHORT' ? 'BUY' : side) 
    : (side === 'BUY' || side === 'SELL' ? 'LONG' : side);

  const handleModeChange = (newMode: 'SPOT' | 'PERPS') => {
    setMode(newMode);
    if (newMode === 'SPOT') setSide('BUY');
    else setSide('LONG');
  };

  return (
    <div class="flex flex-col h-full bg-[#0C0C0C] animate-fade-in pb-20">
      {/* Header Stat */}
      <div class="px-4 py-3 border-b border-white/5 flex justify-between items-center bg-[#0C0C0C] z-10">
        <div class="flex items-center gap-3">
            <div class="flex items-center gap-2 cursor-pointer hover:bg-white/5 p-1 rounded-lg transition-colors">
                <img src={INITIAL_TOKENS[0].image} class="w-6 h-6 rounded-full" />
                <span class="font-bold text-lg">SOL-PERP</span>
                <ChevronDown size={16} class="text-gray-500" />
            </div>
            <span class="text-xs bg-green-500/10 text-green-500 px-2 py-0.5 rounded font-bold">+5.4%</span>
        </div>
        <button class="p-2 hover:bg-white/5 rounded-full">
            <Settings size={20} class="text-gray-400" />
        </button>
      </div>

      <div class="flex-1 overflow-y-auto scrollbar-hide">
        {/* Main Price Display */}
        <div class="px-5 py-4">
            <div class="text-3xl font-bold font-mono">$142.50</div>
            <div class="text-xs text-gray-500 mt-1 flex gap-4">
                <span>Mark: <span class="text-white">142.52</span></span>
                <span>Index: <span class="text-white">142.48</span></span>
                <span>24h Vol: <span class="text-white">$1.2B</span></span>
            </div>
        </div>

        {/* Chart */}
        <div class="h-64 w-full bg-[#0C0C0C] relative border-y border-white/5">
            <div class="absolute top-3 left-4 flex gap-2 z-10">
                {['15m', '1H', '4H', '1D'].map(tf => (
                    <button key={tf} class="text-[10px] font-bold text-gray-500 hover:text-white bg-[#1C1C1E] px-2 py-1 rounded transition-colors">
                        {tf}
                    </button>
                ))}
            </div>
            <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={CHART_DATA}>
                <defs>
                <linearGradient id="colorPriceTerm" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stop-color="#22c55e" stop-opacity={0.2}/>
                    <stop offset="95%" stop-color="#22c55e" stop-opacity={0}/>
                </linearGradient>
                </defs>
                <Tooltip 
                    contentStyle={{ backgroundColor: '#1C1C1E', border: 'none', borderRadius: '8px', fontSize: '12px' }}
                    itemStyle={{ color: '#fff' }}
                />
                <Area 
                type="monotone" 
                dataKey="price" 
                stroke="#22c55e" 
                fillOpacity={1} 
                fill="url(#colorPriceTerm)" 
                strokeWidth={2}
                />
                <YAxis domain={['auto', 'auto']} hide />
            </AreaChart>
            </ResponsiveContainer>
        </div>

        {/* Trading Interface */}
        <div class="p-4">
            {/* Mode Switcher */}
            <div class="bg-[#1C1C1E] p-1 rounded-xl flex mb-4">
                <button 
                    onClick={() => handleModeChange('SPOT')}
                    class={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${mode === 'SPOT' ? 'bg-[#0C0C0C] text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
                >
                    Spot
                </button>
                <button 
                    onClick={() => handleModeChange('PERPS')}
                    class={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${mode === 'PERPS' ? 'bg-[#0C0C0C] text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
                >
                    Perps
                </button>
            </div>

            {/* Side Switcher */}
            <div class="flex gap-2 mb-4">
                {mode === 'SPOT' ? (
                    <>
                        <button onClick={() => setSide('BUY')} class={`flex-1 py-3 rounded-xl font-bold text-sm transition-colors border ${side === 'BUY' ? 'bg-green-500/10 border-green-500 text-green-500' : 'bg-[#1C1C1E] border-transparent text-gray-500'}`}>Buy</button>
                        <button onClick={() => setSide('SELL')} class={`flex-1 py-3 rounded-xl font-bold text-sm transition-colors border ${side === 'SELL' ? 'bg-red-500/10 border-red-500 text-red-500' : 'bg-[#1C1C1E] border-transparent text-gray-500'}`}>Sell</button>
                    </>
                ) : (
                    <>
                        <button onClick={() => setSide('LONG')} class={`flex-1 py-3 rounded-xl font-bold text-sm transition-colors border ${side === 'LONG' ? 'bg-green-500/10 border-green-500 text-green-500' : 'bg-[#1C1C1E] border-transparent text-gray-500'}`}>Long</button>
                        <button onClick={() => setSide('SHORT')} class={`flex-1 py-3 rounded-xl font-bold text-sm transition-colors border ${side === 'SHORT' ? 'bg-red-500/10 border-red-500 text-red-500' : 'bg-[#1C1C1E] border-transparent text-gray-500'}`}>Short</button>
                    </>
                )}
            </div>

            {/* Input Area */}
            <div class="bg-[#1C1C1E] rounded-2xl p-4 mb-4 border border-white/5 focus-within:border-[#AB9FF2] transition-colors">
                <div class="flex justify-between text-xs text-gray-500 mb-2">
                    <span>Amount (USDC)</span>
                    <span>Avail: $2,400.50</span>
                </div>
                <div class="flex items-center justify-between">
                    <input 
                        type="number" 
                        value={amount}
                        onChange={(e) => setAmount((e.target as HTMLInputElement).value)}
                        placeholder="0.00" 
                        class="bg-transparent text-2xl font-bold w-full focus:outline-none text-white" 
                    />
                    <button class="text-xs font-bold bg-[#2C2C2E] px-2 py-1 rounded text-gray-300 hover:text-white">MAX</button>
                </div>
            </div>

            {/* Leverage Slider (Perps Only) */}
            {mode === 'PERPS' && (
                <div class="mb-6">
                    <div class="flex justify-between text-xs font-bold mb-3">
                        <span class="text-gray-500">Leverage</span>
                        <span class="text-[#AB9FF2]">{leverage}x</span>
                    </div>
                    <input 
                        type="range" 
                        min="1" 
                        max="40" 
                        step="1"
                        value={leverage}
                        onChange={(e) => setLeverage(parseInt((e.target as HTMLInputElement).value))}
                        class="w-full accent-[#AB9FF2] h-1.5 bg-[#2C2C2E] rounded-lg appearance-none cursor-pointer"
                    />
                    <div class="flex justify-between text-[10px] text-gray-600 mt-2 font-mono">
                        <span>1x</span>
                        <span>10x</span>
                        <span>20x</span>
                        <span>30x</span>
                        <span>40x</span>
                    </div>
                </div>
            )}

            {/* Order Summary */}
            <div class="space-y-2 mb-6">
                 <div class="flex justify-between text-xs">
                     <span class="text-gray-500">Entry Price</span>
                     <span class="text-white font-mono">Market</span>
                 </div>
                 <div class="flex justify-between text-xs">
                     <span class="text-gray-500">Est. Fee</span>
                     <span class="text-white font-mono">$0.04</span>
                 </div>
                 {mode === 'PERPS' && (
                    <div class="flex justify-between text-xs">
                        <span class="text-gray-500">Liquidation Price</span>
                        <span class="text-red-400 font-mono">
                            {side === 'LONG' ? (142.50 * (1 - 1/leverage)).toFixed(2) : (142.50 * (1 + 1/leverage)).toFixed(2)}
                        </span>
                    </div>
                 )}
            </div>

            {/* Action Button */}
            <button class={`w-full py-4 rounded-xl font-bold text-lg mb-8 shadow-lg active:scale-[0.98] transition-transform ${
                currentSide === 'BUY' || currentSide === 'LONG' 
                ? 'bg-[#22c55e] text-black shadow-green-500/20' 
                : 'bg-[#ef4444] text-white shadow-red-500/20'
            }`}>
                {currentSide} SOL {mode === 'PERPS' && `${leverage}x`}
            </button>

            {/* Tabs for Order Book / History */}
            <div class="border-t border-white/5 pt-4">
                <div class="flex gap-6 mb-4">
                    <button class="text-sm font-bold text-white border-b-2 border-[#AB9FF2] pb-1">Order Book</button>
                    <button class="text-sm font-bold text-gray-500 pb-1">Recent Trades</button>
                    <button class="text-sm font-bold text-gray-500 pb-1">Positions (0)</button>
                </div>
                
                {/* Visual Order Book */}
                <div class="flex gap-1 text-[10px] font-mono">
                    <div class="flex-1 flex flex-col gap-0.5">
                        <div class="text-gray-500 mb-1">Bids</div>
                        {[...Array(5)].map((_, i) => (
                             <div key={i} class="flex justify-between px-1 py-0.5 bg-green-500/5 rounded">
                                 <span class="text-green-500">{(142.40 - i * 0.05).toFixed(2)}</span>
                                 <span class="text-gray-400">{(Math.random() * 100).toFixed(0)}</span>
                             </div>
                        ))}
                    </div>
                    <div class="flex-1 flex flex-col gap-0.5">
                        <div class="text-gray-500 mb-1">Asks</div>
                        {[...Array(5)].map((_, i) => (
                             <div key={i} class="flex justify-between px-1 py-0.5 bg-red-500/5 rounded">
                                 <span class="text-red-500">{(142.60 + i * 0.05).toFixed(2)}</span>
                                 <span class="text-gray-400">{(Math.random() * 100).toFixed(0)}</span>
                             </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};