

export enum AssetType {
  TOKEN = 'TOKEN',
  NFT = 'NFT'
}

export interface Token {
  id: string;
  symbol: string;
  name: string;
  balance: number;
  price: number;
  change24h: number;
  network: 'SOL' | 'ETH' | 'BTC' | 'POLY';
  image: string;
  marketCap?: number;
  description?: string;
}

export interface NFT {
  id: string;
  name: string;
  collection: string;
  image: string;
  isSpam: boolean;
  estValueSol: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  subtitle?: string;
  type: 'success' | 'error' | 'burn';
  image?: string;
}

export interface TransactionDetails {
  type: 'SWAP' | 'SEND' | 'DAPP';
  fromToken: Token;
  toToken?: Token; // For Swap or DApp
  fromAmount: number;
  toAmount?: number; // For Swap
  recipient?: string; // For Send
  fee: number;
  network: string;
  dAppName?: string;
  dAppIcon?: string;
}

export interface TransactionHistoryItem {
  id: string;
  type: 'SWAP' | 'SEND' | 'RECEIVE' | 'BURN' | 'STAKE' | 'DAPP';
  title: string;
  subtitle: string;
  amount: string;
  date: string;
  status: 'CONFIRMED' | 'FAILED';
  image?: string;
  direction: 'IN' | 'OUT';
}

export interface DApp {
  id: string;
  name: string;
  description: string;
  icon: string;
  users: string;
  category: string;
  url: string;
}

export interface Validator {
  id: string;
  name: string;
  apy: number;
  totalStaked: string;
  image?: string;
  verified: boolean;
}

export interface SocialPost {
  id: string;
  user: string;
  avatar: string;
  action: string;
  target: string;
  time: string;
  type: 'buy' | 'sell' | 'mint' | 'stake';
  amount?: string;
}

export interface TrackedWallet {
  address: string;
  name?: string;
  label?: 'Whale' | 'Smart Money' | 'Dev' | 'Friend';
  netWorth: number;
  topTokens: string[];
  chain: 'SOL' | 'ETH';
  recentActivity?: TransactionHistoryItem[];
}

export enum Tab {
  HOME = 'HOME',
  TERMINAL = 'TERMINAL',
  TRACK = 'TRACK',
  EXPLORE = 'EXPLORE',
  SETTINGS = 'SETTINGS'
}